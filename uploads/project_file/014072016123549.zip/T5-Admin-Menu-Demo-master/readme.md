# T5 Admin Menu Demo

How to use custom admin pages by examples.

This plugin registers three admin menu pages and loads a script and a stylesheet
for two pages without touching any other admin page.  
The third page illustrates how to include a file in an admin page.

If you have ideas for or questions about more examples 
[open an issue](https://github.com/toscho/T5-Admin-Menu-Demo/issues). 